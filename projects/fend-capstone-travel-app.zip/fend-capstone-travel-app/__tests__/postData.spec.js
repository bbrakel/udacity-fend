import {
    handlePOST
} from "../src/client/js/postData";

describe("Testing handlePOST()", () => {
    test("TEST: handlePOST()", () => {
        handlePOST();
    })
})