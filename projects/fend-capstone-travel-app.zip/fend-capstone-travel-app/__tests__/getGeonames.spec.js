import {
    fetchGeonames
} from "../src/client/js/getGeonames"

describe("Testing fetchGeonames()", () => {
    test("TEST: fetchGeonames()", () => {
        fetchGeonames();
    })
})