import {
    fetchDarkSky
} from "../src/client/js/getDarkSky"

describe("Testing fetchDarkSky()", () => {
    test("TEST: fetchDarkSky()", () => {
        fetchDarkSky();
    })
})